import SwiftUI

public struct Icon: View {
    let person: Person
    var color: Color = normalIndividualColor
    @State var didTap: Bool = false
    @State var changeColor: Color = normalIndividualColor
    @State var lineWidth: CGFloat = 0
    
    public init(person: inout Person) {
        self.person = person
        self.color = person.getColor()
    }
    
    public func resetButton() {
        self.didTap = false
    }
    
    public var body: some View {
        return Button(action: {
            self.didTap.toggle()
            self.person.changeIsolation()
            self.changeColor = self.person.getColor()
            self.lineWidth = self.person.getLineWidth()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
                self.didTap = false
            })
        }) {
            Image(systemName: individualImage)
                .resizable()
                .frame(width: iconSize, height: iconSize)
                .foregroundColor(didTap ? changeColor : self.person.getColor())
                .overlay(Circle()
                    .stroke(isolationStrokeColor, lineWidth: (didTap ? self.lineWidth : self.person.getLineWidth())))
        }
    }
}
