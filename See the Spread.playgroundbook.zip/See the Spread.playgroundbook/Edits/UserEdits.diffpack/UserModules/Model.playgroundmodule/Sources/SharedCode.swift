import SwiftUI

// Customizable values --------------------
public let numberOfRows = 8
public let R0 = 2
public let enableSelfIsolation = true

public let iconSize: CGFloat = 35.0
public let individualImage = "circle.fill"
public let normalIndividualColor = Color.init(UIColor(red: 72/255.0, green: 159/255.0, blue: 181/255.0, alpha: 1))
public let sickIndividualWithNoSymptonColor = Color.init(UIColor(red: 255/255.0, green: 166/255.0, blue: 43/255.0, alpha: 1))
public let sickIndividualWithSymptonColor = Color.init(UIColor(red: 195/255.0, green: 98/255.0, blue: 98/255.0, alpha: 1))

public let isolationStrokeColor = Color.init(UIColor.label)// Color.init(UIColor(red: 237/255.0, green: 231/255.0, blue: 227/255.0, alpha: 1))
public let isolationStrokeWidth: CGFloat = 3
// ----------------------------------------

public var people: [Person] = []
public let numberOfPeople = numberOfRows * numberOfRows

public func getNewPeople() -> [Person] {
    var people: [Person] = []
    for id in 0 ..< numberOfPeople {
        people.append(Person(id: id))
    }
    let startId = Int.random(in: 0 ..< numberOfPeople)
    people[startId].getSick()
    return people
}

public func getProtectedPeople() -> [Person] {
    var people: [Person] = []
    let protectedRow = numberOfRows / 2
    for id in 0 ..< numberOfPeople {
        people.append(Person(id: id))
        if id / numberOfRows == protectedRow {
            people[id].changeIsolation()
        }
    }
    let startId = Int.random(in: 0 ..< numberOfRows)
    people[startId].getSick()
    return people
}

public func spreadAroundSociety(people: inout [Person]) -> Void{
    for i in 0..<numberOfPeople {
        let person = people[i]
        if !person.spreadedByThisRound {
            if person.getIsolationCondition() {
                let percentage = Int.random(in: 0...100)
                if percentage > 5 {
                    continue
                }
            }
            person.spread(people: &people)
        } else {
            person.spreadedByThisRound = false
        }
    }
}

