import SwiftUI

public class Person: ObservableObject{
    @Published var isSick = false
    @Published var hasShownSympton = false
    @Published var isIsolated = false
    @Published var infectedCount = 0
    var id: Int
    var spreadedByThisRound = false
    var sickDays = 0
    
    public init(id: Int) {
        self.id = id
    }
    
    public init(id: Int, isSick: Bool) {
        self.id = id
        self.isSick = isSick
    }
    
    public init(id: Int, isSick: Bool, hasShownSympton: Bool) {
        self.id = id
        self.isSick = isSick
        self.hasShownSympton = hasShownSympton
    }
    
    public func getSicknessCondition() -> Bool {
        return self.isSick
    }
    
    public func getSymptonCondition() -> Bool {
        return self.hasShownSympton
    }
    
    public func getIsolationCondition() -> Bool {
        return self.isIsolated
    }
    
    public func isSpreadedByThisRound() -> Bool {
        return self.spreadedByThisRound
    }
    
    public func toggleSpreadedFlag() {
        self.spreadedByThisRound.toggle()
    }
    
    public func getSick() -> Bool {
        if isIsolated {
            let possibility = Int.random(in: 0...100)
            if possibility < 10 {
                self.isSick = true
            }
        } else {
            self.isSick = true
        }
        return self.isSick
    }
    
    public func changeIsolation() {
        self.isIsolated.toggle()
    }
    
    func getPeopleAround() -> [Int] {
        var result: [Int] = []
        let idFrom = [
            "above" : { () -> Int? in
                let aboveId: Int? = self.id - numberOfRows
                return aboveId! < 0 ? nil : aboveId
            },
            "left" : { () -> Int? in
                let lId: Int? = self.id - 1
                return (lId! / numberOfRows != self.id / numberOfRows ||
                    lId! < 0) ? nil : lId
            },
            "right" : { () -> Int? in
                let rId: Int? = self.id + 1
                return (rId! / numberOfRows != self.id / numberOfRows ||
                    rId! >= numberOfPeople) ? nil : rId
            },
            "below" : { () -> Int? in
                let belowId: Int? = self.id + numberOfRows
                return belowId! > numberOfPeople - 1 ? nil : belowId
            },
        ]
        
        if let personId = (idFrom["above"]!)() {
            result.append(personId)
        }
        if let personId = (idFrom["below"]!)() {
            result.append(personId)
        }
        if let personId = (idFrom["left"]!)() {
            result.append(personId)
        }
        if let personId = (idFrom["right"]!)() {
            result.append(personId)
        }
        return result
    }
    
    func spread(people: inout [Person]) -> Void {
        if isSick && infectedCount < R0 {
            let infectionId = self.getPeopleAround().randomElement()!
            let notTryingToInfectSickPerson = !people[infectionId].isSick
            let doneInfection = people[infectionId].getSick()
            if notTryingToInfectSickPerson && doneInfection {
                self.infectedCount += 1
            }
            people[infectionId].spreadedByThisRound = true
        }
        if isSick {
            increaseSickDays()
        }
    }
    
    func increaseSickDays() {
        self.sickDays += 1
        if sickDays >= 7 {
            self.hasShownSympton = true
            self.isIsolated = enableSelfIsolation
        }
    }
    
    public func getColor() -> Color {
        if self.isSick {
            if hasShownSympton {
                return sickIndividualWithSymptonColor
            }
            return sickIndividualWithNoSymptonColor
        } 
        return normalIndividualColor
    }
    
    public func getLineWidth() -> CGFloat {
        if self.isIsolated {
            return isolationStrokeWidth
        } else {
            return 0
        }
    }
}
